#!~/.gcal_env/bin/python3
import requests
from icalendar import Calendar
from datetime import datetime
from dateutil import tz

ICAL_URL = "insert ical url from https://calendar.google.com/calendar/"
MAX_EVENTS = 5

def get_events():
    try:
        response = requests.get(ICAL_URL)
        calendar = Calendar.from_ical(response.content)
        events_list = []
        now = datetime.now(tz.tzlocal())
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

        for component in calendar.walk():
            if component.name == "VEVENT":
                summary = str(component.get('summary'))
                start = component.get('dtstart').dt
                
                if not isinstance(start, datetime):
                    start = datetime.combine(start, datetime.min.time(), tzinfo=tz.tzlocal())
                
                if start.tzinfo:
                    start = start.astimezone(tz.tzlocal())
                
                if start >= today_start:
                    events_list.append((start, summary))

        events_list.sort()
        for start, summary in events_list[:MAX_EVENTS]:
            print(f"${{color1}}{start.strftime('%a %d %b %H:%M')}${{color}} - {summary}")
            
    except Exception:
        print("Calendar Unavailable")

if __name__ == "__main__":
    get_events()
