#!~/.gcal_env/bin/python3
import requests
from icalendar import Calendar
from datetime import datetime, date, timedelta
from dateutil import tz
from dateutil.rrule import rrulestr

ICAL_URL  = "insert ical url from https://calendar.google.com/calendar/"
MAX_EVENTS = 8
LOOKAHEAD  = 30  
TITLE_MAX  = 24
LOC_MAX    = 22

R  = "${color}"
C1 = "${color1}"  
C2 = "${color2}" 
C3 = "${color3}"  
C4 = "${color4}"   
C5 = "${color5}"   
C6 = "${color6}"   
C7 = "${color7}"   


def trunc(s, n):
    s = s.strip()
    return s if len(s) <= n else s[:n - 1] + "…"


def fmt_time(start):
    return start.strftime("%H:%M") if isinstance(start, datetime) else "all day"


def time_until(start, now):
    if isinstance(start, datetime):
        secs = int((start - now).total_seconds())
    else:
        secs = int((datetime.combine(start, datetime.min.time(),
                    tzinfo=tz.tzlocal()) - now).total_seconds())
    if secs < 3600:  return f"{max(1, secs // 60)}m"
    if secs < 86400: return f"{secs // 3600}h"
    return f"{secs // 86400}d"


def day_bucket(start, today):
    d = start.date() if isinstance(start, datetime) else start
    delta = (d - today).days
    if delta == 0: return "TODAY",                       C4
    if delta == 1: return "TOMORROW",                    C5
    if delta <= 6: return d.strftime("%A").upper(),      C6
    return d.strftime("%-d %b").upper(),                 C7


def normalise(raw):
    local = tz.tzlocal()
    if isinstance(raw, datetime):
        return raw.astimezone(local) if raw.tzinfo else raw.replace(tzinfo=local)
    return raw 


def in_window(start, now, window_end):
    if isinstance(start, datetime):
        return now < start <= window_end
    today = now.date()
    return today <= start <= window_end.date()


def expand(component, now, window_end):
    raw      = component.get("dtstart").dt
    summary  = trunc(str(component.get("summary") or "No Title"), TITLE_MAX)
    location = trunc(str(component.get("location") or ""), LOC_MAX)
    local    = tz.tzlocal()
    dtstart  = normalise(raw)

    rrule_prop = component.get("rrule")
    if rrule_prop:
        try:
            if isinstance(dtstart, datetime):
                ds_naive = dtstart.replace(tzinfo=None)
                ws = now.replace(tzinfo=None)
            else:
                ds_naive = datetime.combine(dtstart, datetime.min.time())
                ws = datetime.combine(now.date(), datetime.min.time())

            we = ws + timedelta(days=LOOKAHEAD)
            rule_text = f"DTSTART:{ds_naive.strftime('%Y%m%dT%H%M%S')}\nRRULE:{rrule_prop.to_ical().decode()}"
            rule = rrulestr(rule_text, ignoretz=True, dtstart=ds_naive)

            for occ in rule.between(ws, we, inc=True):
                if isinstance(dtstart, datetime):
                    aware = occ.replace(tzinfo=local)
                    if in_window(aware, now, window_end):
                        yield aware, summary, location
                else:
                    d = occ.date()
                    if in_window(d, now, window_end):
                        yield d, summary, location
        except Exception:
            if in_window(dtstart, now, window_end):
                yield dtstart, summary, location
    else:
        if in_window(dtstart, now, window_end):
            yield dtstart, summary, location


def sort_key(item):
    s = item[0]
    if isinstance(s, datetime):
        return s
    return datetime.combine(s, datetime.min.time(), tzinfo=tz.tzlocal())


def get_events():
    url = ICAL_URL
    headers = {"Cache-Control": "no-cache, no-store", "Pragma": "no-cache"}

    try:
        r = requests.get(url, headers=headers, timeout=12)
        r.raise_for_status()
    except requests.exceptions.ConnectionError:
        print(f"{C3}  ⚠  no network{R}"); return
    except requests.exceptions.Timeout:
        print(f"{C3}  ⚠  timed out{R}"); return
    except requests.exceptions.HTTPError as e:
        print(f"{C3}  ⚠  HTTP {e.response.status_code}{R}"); return
    except Exception:
        print(f"{C3}  ⚠  fetch failed{R}"); return

    try:
        cal = Calendar.from_ical(r.content)
    except Exception:
        print(f"{C3}  ⚠  bad calendar data{R}"); return

    now        = datetime.now(tz.tzlocal())
    window_end = now + timedelta(days=LOOKAHEAD)

    events = []
    for comp in cal.walk():
        if comp.name == "VEVENT":
            for item in expand(comp, now, window_end):
                events.append(item)

    events.sort(key=sort_key)
    events = events[:MAX_EVENTS]

    if not events:
        print(f"{C3}  nothing scheduled{R}")
        return

    cur_bucket = None
    for start, summary, location in events:
        label, color = day_bucket(start, now.date())

        if label != cur_bucket:
            if cur_bucket is not None:
                print()
            print(f"  {color}{label}{R}")
            cur_bucket = label

        t = fmt_time(start)
        print(f"  {C1}{t:<8}{R}{C2}{summary}{R}")
        if location:
            print(f"           {C3}⌖ {location}{R}")


if __name__ == "__main__":
    get_events()
